package de.Fabi.mlgrush.enums;

public enum TeamType {

    TEAM_1,
    TEAM_2,
    NONE

}
